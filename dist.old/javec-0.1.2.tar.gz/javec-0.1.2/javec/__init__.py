from .argsHandler import handler

if __name__ == "__main__":

    handler()
